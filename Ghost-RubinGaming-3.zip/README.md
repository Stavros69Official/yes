# G H Ø S T

> **Do `python3 Ghost.py` on Console or Shell to Run**

<sub>👻 Ghost - Enhancing your Discord experience since 2021.</sub>
